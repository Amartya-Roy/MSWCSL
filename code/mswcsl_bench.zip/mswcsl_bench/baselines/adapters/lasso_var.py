"""Lasso-VAR linear reference: per-node Lasso on lags 1..p with BIC (app_experiments.tex, Baselines).

Re-implementation from the paper's definition; the archival Lasso-VAR code is not in this release.
Columns are standardized per replicate; each response X_j(t) is regressed on all variables at lags
1..p (stacked replicates) with sklearn LassoLarsIC(criterion="bic"). Nonzero coefficients are edges.
"""
from __future__ import annotations

import numpy as np

SPEC = {
    "name": "Lasso-VAR",
    "target": "lagged",
    "lag_resolved": True,
    "env": "core",
    "uses_gpu": False,
    "optimizer": "LARS path, BIC model selection (sklearn LassoLarsIC)",
    "upstream": "scikit-learn LassoLarsIC; rule from app_experiments.tex",
    "defaults": {"criterion": "bic"},
    "deviations": ["re-implemented from the paper definition; archival code unavailable"],
    "threshold_rule": "edge iff the BIC-selected Lasso coefficient is nonzero",
}


def _design(reps, p: int):
    Ys, Zs = [], []
    for x in reps:
        x = np.asarray(x, dtype=np.float64)
        x = x - x.mean(axis=0)
        sd = x.std(axis=0)
        sd[sd == 0] = 1.0
        x = x / sd
        T = x.shape[0]
        if T <= p:
            continue
        Ys.append(x[p:])
        Zs.append(np.hstack([x[p - k:T - k] for k in range(1, p + 1)]))   # block k-1 <-> lag k
    return np.vstack(Ys), np.vstack(Zs)


def run(X, p, seed=0, device="cpu", workdir=None, criterion="bic", **unused):
    from sklearn.linear_model import LassoLarsIC

    reps = X if isinstance(X, (list, tuple)) else [X]
    Y, Z = _design(reps, int(p))
    d = Y.shape[1]
    S = np.zeros((d, d, p + 1))
    for j in range(d):
        coef = LassoLarsIC(criterion=criterion, fit_intercept=False).fit(Z, Y[:, j]).coef_
        for k in range(1, p + 1):
            S[:, j, k] = np.abs(coef[(k - 1) * d:k * d])
    G = (S > 0).astype(np.int8)
    return {"S": S, "G": G, "meta": {"flags": [], "deviations": SPEC["deviations"]}}
